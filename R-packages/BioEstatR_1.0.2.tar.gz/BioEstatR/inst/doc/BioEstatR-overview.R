## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(BioEstatR)
data(osteo)

## ----rls----------------------------------------------------------------------
# Ejemplo de regresión lineal simple
rls(imc ~ peso, data = osteo, grf=F)

## ----rlm----------------------------------------------------------------------
# Ejemplo de regresión lineal múltiple
new_data <- data.frame(peso = c(70, 80), talla = c(170, 180))
rlm(imc ~ peso + talla, data = osteo, pred = new_data, grf=F)

## ----rlogits------------------------------------------------------------------
# Ejemplo de regresión logística simple
rlogits(osteo_cue ~ imc, data = osteo)

## ----rlogitm, warning=F-------------------------------------------------------
# Ejemplo de regresión logística múltiple
rlogitm(osteo_cue ~ imc + edad + tevol, data = osteo, grf=T)

## ----icp----------------------------------------------------------------------
# Comparación de métodos: exacto, Wilson, Wald y Agresti-Coull
icp(x = 25, n = 210)

## ----icl----------------------------------------------------------------------
# Método exacto (Garwood) y aproximación normal
icl(x = 25, n = 210)

## ----tabla2x2-----------------------------------------------------------------
# Análisis completo de una tabla 2x2 en estudio transversal
tabla2x2(o = c(20, 26, 60, 294), estudio = "T", tablas = c("F", "S"))

