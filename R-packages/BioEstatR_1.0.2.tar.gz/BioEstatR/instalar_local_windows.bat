@echo off
setlocal enabledelayedexpansion
echo ============================================
echo Instalador LOCAL de BioEstatR para Windows
echo ============================================
echo.
echo Este script instala BioEstatR desde el archivo .tar.gz incluido
echo en esta misma carpeta (sin necesidad de conexion a internet).
echo.

set SCRIPT_DIR=%~dp0
set PKG_FILE=%SCRIPT_DIR%BioEstatR_1.0.1.tar.gz

if not exist "%PKG_FILE%" (
    echo ERROR: No se encuentra %PKG_FILE%
    echo Ejecuta primero 'R CMD build .' en la carpeta del paquete.
    pause
    exit /b 1
)

echo [1/2] Instalando dependencias (requiere internet solo esta vez)...
Rscript -e "install.packages(c('ggplot2','dplyr','tidyr','tibble','broom','survival','survminer','epiR','MASS','car','lmtest','sandwich'), repos='https://cran.r-project.org')"

echo [2/2] Instalando BioEstatR desde archivo local...
R CMD INSTALL "%PKG_FILE%"

echo.
echo Instalacion completada. Abre R o RStudio y ejecuta: library(BioEstatR)
pause
